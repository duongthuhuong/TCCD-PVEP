PROTOTYPE TCCD PVEP v2.2 - CÓ LỜI DẪN

- Nhấn “Bật lời dẫn” ở thanh trên cùng để nghe giọng đọc.
- Trình duyệt sử dụng giọng Vietnamese Text-to-Speech nếu thiết bị có cài đặt.
- Nút CC bật/tắt phụ đề lời dẫn.
- Lời dẫn tự đọc khi chuyển slide sau khi đã bật.
- Đây là voice-over tổng hợp qua Web Speech API, chưa phải tệp MP3 thu âm chuyên nghiệp.
- Khuyến nghị mở bằng Microsoft Edge trên Windows có giọng tiếng Việt.
